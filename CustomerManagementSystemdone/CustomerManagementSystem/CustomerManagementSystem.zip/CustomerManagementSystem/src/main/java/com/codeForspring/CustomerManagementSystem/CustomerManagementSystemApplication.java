package com.codeForspring.CustomerManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerManagementSystemApplication {

	public static void main(String[] args) {

		SpringApplication.run(CustomerManagementSystemApplication.class, args);
	}

}
